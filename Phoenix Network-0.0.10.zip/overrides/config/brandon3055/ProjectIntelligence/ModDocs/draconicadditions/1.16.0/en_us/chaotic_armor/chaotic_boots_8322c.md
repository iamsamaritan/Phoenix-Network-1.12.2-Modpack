﻿§align:center
##### §nChaotic Boots§n

§stack[draconicadditions:chaotic_boots]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

Immune to falling damage
Jump boost
Uphill Step Assist (Configurable)
+120 Base Shield Capacity
+6 Armor Toughness
+6 Armor

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicadditions:chaotic_boots]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}