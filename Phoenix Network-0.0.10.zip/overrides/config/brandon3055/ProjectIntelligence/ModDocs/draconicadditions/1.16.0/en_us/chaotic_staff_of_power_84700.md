§align:center
##### §nChaotic Staff of Power§n

§stack[draconicadditions:chaotic_staff_of_power]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
The Chaotic Staff of Power may seem like the ultimate dream tool come true at first glance, but is infusing pure chaos into a tool really that good of an idea?  Turns out that it's actually somewhere in the middle.

Awakened Draconium, if used properly, is able to project a shield to protect you from chaotic energies.  The good news is that this can be used to your advantage to craft a staff infused with said chaotic energy!  The bad news?  For your own protection, this shield must be in place, but it prevents you from using it to mine out blocks; in fact, it even prevents you from interacting with the customization interface!  Until you figure out a solution to this new problem, though, it's perfectly fine to direct the power of this new staff at your foes!  The chaos contained within this staff also has a certain hunger to it, causing it to slice through the air as if it was weightless.

§b§nStats

§660,000,000 RF - 1,920,000,000 RF Total Capacity

§61x1 AOE

§61 Depth

§6120 - 240 Damage

§62 Attacks/Second

§65x5 - 15x15 Attack AOE

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicadditions:chaotic_staff_of_power]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}