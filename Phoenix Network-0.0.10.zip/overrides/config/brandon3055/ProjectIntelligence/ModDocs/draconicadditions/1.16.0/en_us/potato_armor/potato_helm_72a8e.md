§align:center
##### §nEnergized Potato Helmet

§stack[draconicadditions:potato_helm]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

+2.4 Base Shield Capacity
+1 Armor

§rule{colour:0x606060,height:3,width:100%,top_pad:0}

In order to get this item, you must drop, shake (right-click), or smack a mob with an §link[draconicadditions:infused_potato_armor/infused_potato_helm]{alt_text:"Infused Potato Helmet"}.

§oNote: Modpack authors may disable one or all of these methods of transformation.  In this case, potential recipes are listed below.

§recipe[draconicadditions:potato_helm]{spacing:4}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}