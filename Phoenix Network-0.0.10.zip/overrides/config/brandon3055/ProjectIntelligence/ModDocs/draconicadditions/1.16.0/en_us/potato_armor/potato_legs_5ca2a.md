§align:center
##### §nEnergized Potato Leggings

§stack[draconicadditions:potato_legs]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

+4.8 Base Shield Capacity
+1 Armor

§rule{colour:0x606060,height:3,width:100%,top_pad:0}

In order to get this item, you must drop, shake (right-click), or smack a mob with an §link[draconicadditions:infused_potato_armor/infused_potato_legs]{alt_text:"Infused Potato Leggings"}.

§oNote: Modpack authors may disable one or all of these methods of transformation.  In this case, potential recipes are listed below.

§recipe[draconicadditions:potato_legs]{spacing:4}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}