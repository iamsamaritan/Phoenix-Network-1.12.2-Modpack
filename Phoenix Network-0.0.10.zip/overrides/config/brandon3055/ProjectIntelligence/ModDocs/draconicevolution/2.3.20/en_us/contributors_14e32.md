##### §b§nContributors§n§b
//§rule{colour:0x606060,height:3,width:100%}

§n§6Covers1624§b§n
Covers is the biggest DE contributor as far as DE 1.10+ is concerned. His work with CCL has been an enormous help and is what makes a lot of the fancy rendering in 1.10+ possible! He has also been a big help with some of the DE code. He is all around great guy and a very good friend! 
§link[https://twitter.com/covers1624]{alt_text:"Visit Twitter",colour:0xE0E0E0,colour_hover:0xFFFFA0,padding:4,link_style:vanilla} §link[https://www.twitch.tv/covers1624]{alt_text:"Visit Twitch",colour:0xE0E0E0,colour_hover:0xFFFFA0,padding:4,link_style:vanilla}
§rule{colour:0x606060,height:3,width:100%}

§n§6GreatOrator§b§n
GreatOrator has always been and will always be one of my best friends. He was the first person I met in the modded community when we both played on the same modded 1.4.7 server quite a few years back. After playing with mods for a while, we both decided we wanted to take it a step further. GreatOrator started working on the modpack that is now known as Tolkiencraft and I decided to start messing with Java and working on an add-on for Tolkiencraft that would one day be known as Draconic Evolution.

If you told us back then how far we would go, we never would have believed it! To be honest, I'm still having a hard time believing it. I think it was the amazing success of the Tolkiencraft modpack that really helped DE become as popular as it is today, as when people learned about Tolkiencraft, they also learned about DE.
§link[https://twitter.com/GreatOrator73]{alt_text:"Visit Twitter",colour:0xE0E0E0,colour_hover:0xFFFFA0,padding:4,link_style:vanilla} §link[https://www.twitch.tv/greatorator]{alt_text:"Visit Twitch",colour:0xE0E0E0,colour_hover:0xFFFFA0,padding:4,link_style:vanilla}
§rule{colour:0x606060,height:3,width:100%}

§n§6Sn0wshepherd§b§n
I must also thank Sn0wshepherd for her contribution to DE. Almost all of the textures and 3D tool/armor models used from 1.10 to 1.12.2 were created by her!
§link[https://twitter.com/Sn0wShepherd]{alt_text:"Visit Twitter",colour:0xE0E0E0,colour_hover:0xFFFFA0,padding:4,link_style:vanilla} §link[https://www.twitch.tv/sn0wshepherd]{alt_text:"Visit Twitch",colour:0xE0E0E0,colour_hover:0xFFFFA0,padding:4,link_style:vanilla}
§rule{colour:0x606060,height:3,width:100%}
 
##### §b§nPatreon§n§b
§aThe following people are supporting me or have previously supported me on patreon! The support these people give really helps make what I do possible. For this, I owe them all a debt of gratitude.

§table{width:100%,render_cells:false} 
<table column_layout="1*,1*">
<tr>
<td>
§6Robert W
§r(Since 08/06/2015)§r
</td>
<td>
§6pxoxd
§r(Since 10/12/2015)§r
</td>
</tr>
<tr>
<td>
§6antric83
§r(Since 14/04/2016)§r
</td>
<td>
§6SassyAmber
§r(Since 25/05/2016)§r
</td>
</tr>
<tr>
<td>
§6GreatOrator
§r(Since 02/06/2016)§r
</td>
<td>
§6Drekryan
§r(Since 24/06/2016)§r
</td>
</tr>
<tr>
<td>
§6Der DracheTV
§r(Since 26/06/2016)§r
</td>
<td>
§6Jordan
§r(Since 20/07/2016)§r
</td>
</tr>
<tr>
<td>
§6ModAPI
§r(Since 29/11/2016)§r
</td>
<td>
§6Mikepet
§r(Since 09/12/2016)§r
</td>
</tr>
<tr>
<td>
§6Nick_J_M
§r(Since 19/01/2017)§r
</td>
<td>
§6Halacon
§r(Since 23/01/2017)§r
</td>
</tr>
<tr>
<td>
§6Edward
§r(Since 27/01/2017)§r
</td>
<td>
§6WolufHD
§r(Since 29/03/2017)§r
</td>
</tr>
<tr>
<td>
§6Morpheus1101
§r(Since 15/04/2017)§r
</td>
<td>
§6exus_Chris
§r(Since 18/04/2017)§r
</td>
</tr>
<tr>
<td>
§6Zudakai
§r(Since 21/04/2017)§r
</td>
<td>
§6duomaz
§r(Since 15/04/2017)§r
</td>
</tr>
<tr>
<td>
§6Snakemgr12
§r(Since 12/05/2017)§r
</td>
<td>
§6Mhoku_
§r(Since 08/06/2017)§r
</td>
</tr>
<tr>
<td>
§6Connor Love
§r(Since 18/07/2017)§r
</td>
<td>
§6Keith Wagner
§r(Since 20/10/2017)§r
</td>
</tr>
<tr>
<td>
§6awk1995
§r(Since 26/02/2018)§r
</td>
<td>
§6boredi
§r(Since 28/04/2018)§r
</td>
</tr>
<tr>
<td>
§6King_Kookie_
§r(Since 02/08/2018)§r
</td>
<td>
§6lucid4
§r(Since 07/02/2019)§r
</td>
</tr>
<tr>
<td>
§6Kris K
§r(Since 28/02/2019)§r
</td>
<td>
§6Paddycboy
§r(Since 01/03/2019)§r
</td>
</tr>
<tr>
<td>
§6Quarnds
§r(Since Mar 22, 2019)§r
</td>
<td>
§6xtrux
§r(Since Apr 15, 2019)§r
</td>
</tr>
<tr>
<td>
§6jackkeane98
§r(Since Feb 8, 2020)§r
</td>
<td>
§6chaetay
§r(Since Mar 22, 2020)§r
</td>
</tr>
<tr>
<td>
§6STALlN
§r(Since Apr 26, 2020)§r
</td>
<td>
§6elfdafatpizza
§r(Since May 11, 2020)§r
</td>
</tr>
<tr>
<td>
§6muffinman_21
§r(Since May 13, 2020)§r
</td>
<td>
§6Munchkin
§r(Since Jun 9, 2020)§r
</td>
</tr>
<tr>
<td>
§6TheIcicle
§r(Since Sep 20, 2020)§r
</td>
<td>
§6Einhornyordle
§r(Since Jan 31, 2021)§r
</td>
</tr>
</table>
§rule{colour:0x606060,height:3,width:100%}
§img[http://ss.brandon3055.com/45745]{width:118,tooltip:"Click here to visit my patreon page.",link_to:"https://www.patreon.com/brandon3055",border_colour:0x909090,border_colour_hover:0x00FF00,padding:1} 