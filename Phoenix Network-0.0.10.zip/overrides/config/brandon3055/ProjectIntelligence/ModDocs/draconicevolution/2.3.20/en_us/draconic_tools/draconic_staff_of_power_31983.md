§align:center
##### §nDraconic Staff of Power§n

§img[http://ss.brandon3055.com/ff9df]{width:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
The Staff of Power is the ultimate culmination of all your base Draconic Tools, wrapped up into one easy-to-carry package! It is both a mining tool and a powerful weapon with similar abilities to the Draconic Sword, but stronger!

§b§nStats

§648M max RF - Upgradable to 768M.

§65x5 base mining AOE - Upgradable to 11x11.

§65 block dig depth - Upgradable to 11.

§660 base Attack - Upgradable to 105.
It should be noted that because this is such a large, heavy weapon, the attack speed is fairly low.

§65x5 base attack radius - Upgradable to 17x17.
Note: The AOE attack only works when the sword is fully charged.
(Referring to the new vanilla charging mechanic)

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_staff_of_power]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}