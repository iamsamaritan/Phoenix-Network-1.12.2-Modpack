§align:center
##### §nWireless Energy Crystal§n
§stack[draconicevolution:energy_crystal,1,6]{size:64} §stack[draconicevolution:energy_crystal,1,7]{size:64} §stack[draconicevolution:energy_crystal,1,8]{size:64}
§rule{colour:0x606060,height:3,width:100%,top_pad:0}
###### §nStats

§9Basic§r
Capacity: 4M
Max Links: 4
Max Wireless Links: 16

§5Wyvern§r
Capacity: 16M
Max Links: 8
Max Wireless Links: 32

§6Draconic§r
Capacity: 64M
Max Links: 16
Max Wireless Links: 64

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:energy_crystal,1,6]{spacing:2}§recipe[draconicevolution:energy_crystal,1,7]{spacing:2}§recipe[draconicevolution:energy_crystal,1,8]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}