§align:center
##### §nMob Grinder§n

§stack[draconicevolution:grinder]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Everyone needs effective mob farms. For the cost of a bit of RF power, you can kill to your heart's content knowing the forces of the Draconic have your back!

The grinder will kill all mobs in a 7x7 area in front of it.

In order to reduce lag, experience orbs dropped by the grinder will despawn after 30 seconds if not collected. It is recommended that you use something like the EnderIO XP Vacuum to collect the experience orbs (if available).

The grinder can be powered either externally or by a capacitor placed in the capacitor slot in its GUI.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:grinder]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}