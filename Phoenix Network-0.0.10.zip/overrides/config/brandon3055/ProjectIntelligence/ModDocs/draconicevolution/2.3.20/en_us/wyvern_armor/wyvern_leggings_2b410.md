§align:center
##### §nWyvern Leggings§n

§stack[draconicevolution:wyvern_legs]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

+76 Base Shield Capacity
+2 Armor Toughness
+6 Armor
Movement Speed boost

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:wyvern_legs]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}