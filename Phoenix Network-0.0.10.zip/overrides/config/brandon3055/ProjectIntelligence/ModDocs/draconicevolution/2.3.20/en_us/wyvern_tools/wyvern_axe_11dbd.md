§align:center
##### §nWyvern Axe§n

§img[http://ss.brandon3055.com/6b29d]{width:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§b§nStats

§64M max RF - Upgradable to 32M.

§61x1 base mining AOE - Upgradable to 5x5.

§6Tree Harvesting
When enabled, simply hold right-click on the base of a tree and this axe will quickly harvest the entire tree block by block.

This axe can harvest up to 512 blocks at a time.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:wyvern_axe]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}