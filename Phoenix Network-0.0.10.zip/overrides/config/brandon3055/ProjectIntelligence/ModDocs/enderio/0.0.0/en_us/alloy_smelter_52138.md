§stack[enderio:block_simple_alloy_smelter]{size:18,enable_tooltip:false}§stack[enderio:block_alloy_smelter]{size:18,enable_tooltip:false}§stack[enderio:block_enhanced_alloy_smelter]{size:18,enable_tooltip:false}

§recipe[enderio:block_simple_alloy_smelter]{spacing:4}
§recipe[enderio:block_alloy_smelter]{spacing:4}
§recipe[enderio:block_enhanced_alloy_smelter]{spacing:4}
