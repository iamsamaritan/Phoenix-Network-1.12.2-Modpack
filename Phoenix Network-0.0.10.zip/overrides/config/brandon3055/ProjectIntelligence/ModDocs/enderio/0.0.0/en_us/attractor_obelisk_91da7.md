§stack[enderio:block_attractor_obelisk]{size:18,enable_tooltip:false}

§recipe[enderio:block_attractor_obelisk]{spacing:4}