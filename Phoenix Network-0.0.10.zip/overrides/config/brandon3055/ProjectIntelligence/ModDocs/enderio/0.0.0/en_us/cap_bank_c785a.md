§stack[enderio:block_cap_bank,1,1]{size:18,enable_tooltip:false}§stack[enderio:block_cap_bank,1,1,{"enderio:energy":1000000}]{size:18,enable_tooltip:false}§stack[enderio:block_cap_bank,1,2]{size:18,enable_tooltip:false}§stack[enderio:block_cap_bank,1,2,{"enderio:energy":5000000}]{size:18,enable_tooltip:false}§stack[enderio:block_cap_bank,1,3]{size:18,enable_tooltip:false}§stack[enderio:block_cap_bank,1,3,{"enderio:energy":25000000}]{size:18,enable_tooltip:false}§stack[enderio:block_cap_bank,1,0,{"enderio:energy":50000000}]{size:18,enable_tooltip:false}

§recipe[enderio:block_cap_bank,1,1]{spacing:4}
§recipe[enderio:block_cap_bank,1,2]{spacing:4}
§recipe[enderio:block_cap_bank,1,3]{spacing:4}
§recipe[enderio:block_cap_bank,1,0,{"enderio:energy":50000000}]{spacing:4}