§stack[enderio:block_dialing_device]{size:18,enable_tooltip:false}

§recipe[enderio:block_dialing_device]{spacing:4}