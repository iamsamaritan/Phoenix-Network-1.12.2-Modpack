§stack[enderio:block_enchanter]{size:18,enable_tooltip:false}

§recipe[enderio:block_enchanter]{spacing:4}