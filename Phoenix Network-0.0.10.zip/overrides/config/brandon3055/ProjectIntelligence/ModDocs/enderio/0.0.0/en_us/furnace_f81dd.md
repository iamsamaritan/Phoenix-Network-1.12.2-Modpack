§stack[enderio:block_simple_furnace]{size:18,enable_tooltip:false} 
§recipe[enderio:block_simple_furnace]{spacing:4}